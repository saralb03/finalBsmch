const academicLevels = {
    "academicLevels": [
      { "value": "Undergraduate", "label": "Undergraduate" },
      { "value": "Postgraduate", "label": "Postgraduate" },
      { "value": "Ph.D.", "label": "Ph.D." },
      { "value": "Diploma", "label": "Diploma" }
    ]
  }
  export default academicLevels