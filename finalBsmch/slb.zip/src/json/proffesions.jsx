const proffesions = [
    "Computer Science / Software Engineering",
    "Mechanical Engineering",
    "Civil Engineering",
    "Electrical Engineering",
    "Biomedical Engineering",
    "Environmental Science",
    "Business Administration",
    "Marketing",
    "Graphic Design",
    "Web Development",
    "Psychology",
    "Education",
    "Architecture",
    "Nursing",
    "Culinary Arts"
  ]
export default proffesions;