 const toolsPreferredOptions=  ["React","Node.js","Figma","Adobe XD"];
export default toolsPreferredOptions;