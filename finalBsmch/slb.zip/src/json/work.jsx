
const workEnvironment = ["home","zoom","office","hybride","remote"]
export default workEnvironment;