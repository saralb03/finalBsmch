const workDomains= ["Web Development","Mobile App Development","Digital Marketing","Graphic Design"];
export default workDomains;